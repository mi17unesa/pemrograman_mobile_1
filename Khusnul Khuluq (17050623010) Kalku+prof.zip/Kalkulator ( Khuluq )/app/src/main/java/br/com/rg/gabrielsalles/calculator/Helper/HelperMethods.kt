package br.com.rg.gabrielsalles.calculator.Helper


class HelperMethods {
    companion object {
        
        fun add(num1: Double, num2: Double): Double {
            return num1 + num2
        }
        
        fun sub(num1: Double, num2: Double): Double {
            return num1 - num2
        }
        
        fun mult(num1: Double, num2: Double): Double {
            return num1 * num2
        }
        
        fun div(num1: Double, num2: Double): Double {
            return num1 / num2
        }
    }
}