package br.com.rg.gabrielsalles.calculator.Helper

/**
 * Created by gabriel on 07/12/17.
 */
class Constants {
    companion object {
        val OPERATIONS = listOf<Char>('+', '-', '*', '/')
        val NON_NEGATIVE_OPERATIONS = listOf<Char>('+', '*', '/')
    }
}